# E-Learning Platform (MERN Stack)

## Features
- User Authentication
- Course Enrollment
- Quiz System
- Certificate Generation

## Tech Stack
- MongoDB
- Express.js
- React.js
- Node.js

## Setup

### Backend
cd server
npm install
npm start

### Frontend
cd client
npm install
npm start
