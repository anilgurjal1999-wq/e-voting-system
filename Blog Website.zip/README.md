# Blogging Platform (Flask)

## Features
- Create, Read, Update, Delete blog posts
- Bootstrap UI
- SQLite database

## Setup
```bash
pip install -r requirements.txt
python app.py
```

Open: http://127.0.0.1:5000/
